# Encryption / Decryption Tool

## Project Overview
This project is developed using Python and the Cryptography library. It encrypts sensitive messages into unreadable encrypted text and decrypts them back to the original message using a secret key.

## Features
- Message Encryption
- Message Decryption
- Secure Secret Key Generation
- Save Encrypted Messages
- Beginner Friendly Cybersecurity Project

## Technologies Used
- Python
- Cryptography Library

## Project Files
- encrypt.py
- decrypt.py
- encrypted.txt
- secret.key
- requirements.txt
- README.md

## How to Run

### Install Library
pip install cryptography

### Run Encryption
python encrypt.py

### Run Decryption
python decrypt.py

## Author
Divyasree Evuri