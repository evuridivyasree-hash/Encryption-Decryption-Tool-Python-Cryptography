from cryptography.fernet import Fernet

# Generate and save key
key = Fernet.generate_key()

with open("secret.key", "wb") as key_file:
    key_file.write(key)

cipher = Fernet(key)

message = input("Enter message to encrypt: ")

encrypted_message = cipher.encrypt(message.encode())

print("\nEncrypted Message:")
print(encrypted_message.decode())

with open("encrypted.txt", "wb") as file:
    file.write(encrypted_message)

print("\nEncrypted message saved in encrypted.txt")