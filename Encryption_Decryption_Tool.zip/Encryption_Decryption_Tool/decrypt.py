from cryptography.fernet import Fernet

# Load secret key
with open("secret.key", "rb") as key_file:
    key = key_file.read()

cipher = Fernet(key)

# Read encrypted message
with open("encrypted.txt", "rb") as file:
    encrypted_message = file.read()

decrypted_message = cipher.decrypt(encrypted_message)

print("\nDecrypted Message:")
print(decrypted_message.decode())